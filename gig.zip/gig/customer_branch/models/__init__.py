# -*- coding: utf-8 -*-

from . import customer_branch
from . import res_partner