# -*- coding: utf-8 -*-
from odoo import models, fields, api

class ProjectTaskInherit1(models.Model):
    _inherit = 'project.task'
    
    